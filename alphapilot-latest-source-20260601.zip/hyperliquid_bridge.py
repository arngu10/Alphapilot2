import json
import os
import signal
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

ALPHAPILOT_API_URL = os.getenv("ALPHAPILOT_API_URL", "http://localhost:3000")
ALPHAPILOT_BRIDGE_TOKEN = os.getenv("ALPHAPILOT_BRIDGE_TOKEN", "dev-bridge-token")
ALPHAPILOT_MANAGED_BRIDGE_ID = os.getenv("ALPHAPILOT_MANAGED_BRIDGE_ID", "alphapilot-hyperliquid-vps-1")
BRIDGE_ENABLE_LIVE_ORDERS = os.getenv("ALPHAPILOT_BRIDGE_ENABLE_LIVE_ORDERS", "false").lower() == "true"
POLL_INTERVAL_SECONDS = int(os.getenv("ALPHAPILOT_HYPERLIQUID_POLL_INTERVAL_SECONDS", "15"))
DEFAULT_SLIPPAGE = float(os.getenv("ALPHAPILOT_HYPERLIQUID_SLIPPAGE", "0.01"))
LOG_FILE = os.getenv("ALPHAPILOT_HYPERLIQUID_BRIDGE_LOG", r"C:\AlphaPilot\hyperliquid_bridge.log")
RUNNING = True
CONNECTION_CREDENTIALS = {}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def log(message):
    line = f"{utc_now()} {message}"
    print(line, flush=True)
    if LOG_FILE:
        try:
            os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
            with open(LOG_FILE, "a", encoding="utf-8") as file:
                file.write(line + "\n")
        except OSError:
            pass


def stop(*_args):
    global RUNNING
    RUNNING = False
    log("Shutdown requested")


def api_request(path, method="GET", payload=None):
    body = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = urllib.request.Request(
        f"{ALPHAPILOT_API_URL.rstrip('/')}{path}",
        data=body,
        headers={
            "content-type": "application/json",
            "x-alphapilot-bridge-token": ALPHAPILOT_BRIDGE_TOKEN,
            "x-alphapilot-bridge-id": ALPHAPILOT_MANAGED_BRIDGE_ID,
        },
        method=method,
    )

    with urllib.request.urlopen(request, timeout=20) as response:
        text = response.read().decode("utf-8")
        return response.status, json.loads(text) if text else {}


def load_hyperliquid_sdk():
    try:
        import eth_account
        from hyperliquid.exchange import Exchange
        from hyperliquid.info import Info
        from hyperliquid.utils import constants

        return eth_account, Exchange, Info, constants
    except ImportError as error:
        raise RuntimeError("Install dependencies with: pip install hyperliquid-python-sdk eth-account") from error


def api_url(credentials):
    if credentials.get("apiUrl"):
        return credentials["apiUrl"]
    if credentials.get("testnet"):
        _eth_account, _exchange, _info, constants = load_hyperliquid_sdk()
        return constants.TESTNET_API_URL
    _eth_account, _exchange, _info, constants = load_hyperliquid_sdk()
    return constants.MAINNET_API_URL


def normalize_coin(symbol):
    return str(symbol or "").upper().replace("/USD", "").replace("-USD", "").replace("USDC", "").replace("USDT", "")


def build_clients(credentials):
    eth_account, Exchange, Info, _constants = load_hyperliquid_sdk()
    secret_key = credentials.get("secretKey") or credentials.get("privateKey") or credentials.get("apiWalletPrivateKey")
    account_address = credentials.get("accountAddress") or credentials.get("walletAddress")
    if not secret_key:
        raise ValueError("Hyperliquid credentials require secretKey/privateKey/apiWalletPrivateKey.")
    if not account_address:
        raise ValueError("Hyperliquid credentials require accountAddress/walletAddress.")

    base_url = api_url(credentials)
    wallet = eth_account.Account.from_key(secret_key)
    info = Info(base_url, skip_ws=True)
    exchange = Exchange(wallet, base_url, account_address=account_address)
    return wallet, info, exchange, account_address, base_url


def fetch_bridge_connections():
    try:
        _status, response = api_request("/api/bridge/connections?broker=hyperliquid")
        return response.get("data", {}).get("activations", [])
    except (urllib.error.URLError, json.JSONDecodeError) as error:
        log(f"Bridge connection poll failed: {error}")
        return []


def report_broker_connection(connection_id, status, execution_account_ref=None):
    try:
        api_request(
            f"/api/brokers/connections/{connection_id}",
            method="PATCH",
            payload={
                "status": status,
                "managedBridgeId": ALPHAPILOT_MANAGED_BRIDGE_ID,
                "executionAccountRef": execution_account_ref,
            },
        )
    except urllib.error.URLError as error:
        log(f"Broker connection report failed connection={connection_id}: {error}")


def report_account_state(connection, account_ref, user_state):
    margin_summary = user_state.get("marginSummary", {}) if isinstance(user_state, dict) else {}
    asset_positions = user_state.get("assetPositions", []) if isinstance(user_state, dict) else []
    positions = []
    for item in asset_positions:
        position = item.get("position", {}) if isinstance(item, dict) else {}
        if position:
            positions.append(position)

    try:
        api_request(
            "/api/bridge/account-state",
            method="POST",
            payload={
                "userId": connection.get("userId"),
                "brokerConnectionId": connection.get("id"),
                "connectorId": "hyperliquid",
                "managedBridgeId": ALPHAPILOT_MANAGED_BRIDGE_ID,
                "accountRef": account_ref,
                "account": {
                    "currency": "USDC",
                    "accountValue": float(margin_summary.get("accountValue", 0) or 0),
                    "totalMarginUsed": float(margin_summary.get("totalMarginUsed", 0) or 0),
                    "raw": margin_summary,
                },
                "positions": positions,
                "reportedAt": utc_now(),
            },
        )
    except urllib.error.URLError as error:
        log(f"Account state report failed connection={connection.get('id')}: {error}")


def process_bridge_connections():
    for activation in fetch_bridge_connections():
        connection = activation.get("connection") or {}
        credentials = activation.get("credentials")
        connection_id = connection.get("id")
        if not connection_id:
            continue

        if credentials:
            CONNECTION_CREDENTIALS[connection_id] = credentials

        if connection.get("status") != "pending":
            continue

        try:
            _wallet, info, _exchange, account_address, base_url = build_clients(credentials or {})
            state = info.user_state(account_address)
            if not isinstance(state, dict):
                raise RuntimeError("Hyperliquid user_state response was not an object.")
            execution_account_ref = f"hyperliquid:{base_url}:{account_address}"
            report_broker_connection(connection_id, "connected", execution_account_ref=execution_account_ref)
            report_account_state({**connection, "executionAccountRef": execution_account_ref}, execution_account_ref, state)
            log(f"Hyperliquid activation connected connection={connection_id} account={account_address}")
        except Exception as error:
            report_broker_connection(connection_id, "failed")
            log(f"Hyperliquid activation failed connection={connection_id}: {error}")


def fetch_execution_orders():
    try:
        _status, response = api_request("/api/execution/orders?status=queued&limit=10")
        return response.get("data", {}).get("orders", [])
    except (urllib.error.URLError, json.JSONDecodeError) as error:
        log(f"Execution poll failed: {error}")
        return []


def report_execution_order(order_id, status, ticket=None, retcode=None, comment=None, raw=None):
    try:
        api_request(
            "/api/execution/orders",
            method="POST",
            payload={
                "report": {
                    "id": order_id,
                    "status": status,
                    "ticket": ticket,
                    "retcode": retcode,
                    "comment": comment,
                    "raw": raw,
                }
            },
        )
    except urllib.error.URLError as error:
        log(f"Execution report failed order={order_id}: {error}")


def execute_order(order):
    order_id = order.get("id")
    connection_id = order.get("brokerConnectionId")
    symbol = order.get("symbol")

    if order.get("connectorId") != "hyperliquid":
        return

    if order.get("managedBridgeId") != ALPHAPILOT_MANAGED_BRIDGE_ID:
        return

    if order.get("dryRun") or not BRIDGE_ENABLE_LIVE_ORDERS:
        report_execution_order(order_id, "dry_run", comment="Bridge live-order flag is disabled or order is dry-run.")
        log(f"Hyperliquid dry-run order={order_id} symbol={symbol}")
        return

    credentials = CONNECTION_CREDENTIALS.get(connection_id)
    if not credentials:
        report_execution_order(order_id, "rejected", comment="No credentials loaded for broker connection.")
        log(f"Hyperliquid rejected order={order_id} missing_credentials connection={connection_id}")
        return

    try:
        _wallet, _info, exchange, _account_address, _base_url = build_clients(credentials)
        coin = normalize_coin(symbol)
        is_buy = order.get("side") == "long"
        size = float(order.get("volumeLots"))
        slippage = float(credentials.get("slippage", DEFAULT_SLIPPAGE))

        if hasattr(exchange, "market_open"):
            result = exchange.market_open(coin, is_buy, size, None, slippage)
        else:
            result = exchange.order(coin, is_buy, size, float(order.get("entryReference")), {"limit": {"tif": "Ioc"}})

        status = "filled" if isinstance(result, dict) and result.get("status") == "ok" else "rejected"
        report_execution_order(order_id, status, comment="Hyperliquid execution response", raw=result)
        log(f"Hyperliquid {status} order={order_id} coin={coin}")
    except Exception as error:
        report_execution_order(order_id, "rejected", comment=str(error), raw={"error": str(error)})
        log(f"Hyperliquid rejected order={order_id}: {error}")


def process_execution_orders():
    for order in fetch_execution_orders():
        execute_order(order)


def run_once():
    process_bridge_connections()
    process_execution_orders()


def run_loop():
    log(
        "AlphaPilot Hyperliquid bridge started "
        f"api={ALPHAPILOT_API_URL} bridge={ALPHAPILOT_MANAGED_BRIDGE_ID} interval={POLL_INTERVAL_SECONDS}s"
    )

    while RUNNING:
        run_once()
        for _ in range(POLL_INTERVAL_SECONDS):
            if not RUNNING:
                break
            time.sleep(1)

    log("AlphaPilot Hyperliquid bridge stopped")


def main():
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)

    if "--once" in sys.argv:
        run_once()
        raise SystemExit(0)

    run_loop()


if __name__ == "__main__":
    main()
