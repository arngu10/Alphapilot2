import {
  createCipheriv,
  createDecipheriv,
  createHash,
  pbkdf2Sync,
  randomBytes,
  randomUUID,
  timingSafeEqual
} from "node:crypto";
import { writeAuditEvent } from "./audit-log";
import type {
  AlphaPilotSession,
  AlphaPilotUser,
  AlphaPilotUserProfile,
  BrokerConnectionStatus,
  UserAutomationMode,
  UserBrokerConnection,
  UserRiskTolerance
} from "./types";

const supabaseUrl = process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const sessionTtlMs = 1000 * 60 * 60 * 24 * 30;
const passwordIterations = 120000;
const defaultManagedBridgeId = process.env.ALPHAPILOT_MANAGED_BRIDGE_ID ?? "alphapilot-managed-vps-1";
const credentialKeySource =
  process.env.ALPHAPILOT_CREDENTIAL_KEY ??
  (process.env.NODE_ENV === "production" ? "" : "dev-only-alphapilot-credential-key");

type UserRow = {
  id: string;
  email: string;
  password_hash: string;
  password_salt: string;
  display_name: string | null;
  automation_mode: UserAutomationMode | null;
  base_currency: string;
  risk_tolerance: UserRiskTolerance;
  markets: string[];
  onboarding_completed_at: string | null;
  created_at: string;
  updated_at: string;
};

type SessionRow = {
  id: string;
  user_id: string;
  token_hash: string;
  expires_at: string;
  created_at: string;
  revoked_at: string | null;
};

type BrokerConnectionRow = {
  id: string;
  user_id: string;
  broker: string;
  account_label: string | null;
  environment: "demo" | "live";
  status: BrokerConnectionStatus;
  permissions: string[];
  managed_bridge_id: string;
  execution_account_ref: string | null;
  secret_ref: string | null;
  created_at: string;
  last_synced_at: string | null;
};

type BrokerCredentialRow = {
  id: string;
  connection_id: string;
  user_id: string;
  managed_bridge_id: string;
  encrypted_payload: string;
  iv: string;
  auth_tag: string;
  created_at: string;
  rotated_at: string | null;
};

const runtimeUsers: Array<UserRow> = [];
const runtimeSessions: Array<SessionRow> = [];
const runtimeBrokerConnections: Array<BrokerConnectionRow> = [];
const runtimeBrokerCredentials: Array<BrokerCredentialRow> = [];

function isSupabaseConfigured() {
  return Boolean(supabaseUrl && serviceRoleKey);
}

async function supabaseRequest<T>(path: string, init: RequestInit = {}): Promise<T | null> {
  if (!isSupabaseConfigured()) return null;

  try {
    const response = await fetch(`${supabaseUrl}/rest/v1/${path}`, {
      ...init,
      headers: {
        apikey: serviceRoleKey as string,
        Authorization: `Bearer ${serviceRoleKey}`,
        "Content-Type": "application/json",
        Prefer: "return=representation",
        ...init.headers
      },
      cache: "no-store"
    });

    if (response.ok) {
      if (response.status === 204) return null;
      return (await response.json()) as T;
    }
  } catch {
    return null;
  }

  return null;
}

function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

function validateEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function hashPassword(password: string, salt = randomBytes(16).toString("hex")) {
  const hash = pbkdf2Sync(password, salt, passwordIterations, 64, "sha512").toString("hex");
  return { hash, salt };
}

function verifyPassword(password: string, row: UserRow) {
  const candidate = Buffer.from(hashPassword(password, row.password_salt).hash, "hex");
  const stored = Buffer.from(row.password_hash, "hex");
  return candidate.length === stored.length && timingSafeEqual(candidate, stored);
}

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function generateSessionToken() {
  return `aps_${randomBytes(32).toString("base64url")}`;
}

function getCredentialKey() {
  if (!credentialKeySource) {
    throw new Error("ALPHAPILOT_CREDENTIAL_KEY is required for broker credential storage.");
  }

  return createHash("sha256").update(credentialKeySource).digest();
}

function encryptCredentialPayload(payload: unknown) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", getCredentialKey(), iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(payload), "utf8"), cipher.final()]);

  return {
    encrypted_payload: encrypted.toString("base64"),
    iv: iv.toString("base64"),
    auth_tag: cipher.getAuthTag().toString("base64")
  };
}

function decryptCredentialPayload(row: BrokerCredentialRow) {
  const decipher = createDecipheriv("aes-256-gcm", getCredentialKey(), Buffer.from(row.iv, "base64"));
  decipher.setAuthTag(Buffer.from(row.auth_tag, "base64"));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(row.encrypted_payload, "base64")),
    decipher.final()
  ]).toString("utf8");

  return JSON.parse(decrypted) as unknown;
}

function mapUser(row: UserRow): AlphaPilotUser {
  return {
    id: row.id,
    email: row.email,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    profile: {
      displayName: row.display_name,
      automationMode: row.automation_mode,
      baseCurrency: row.base_currency,
      riskTolerance: row.risk_tolerance,
      markets: row.markets ?? [],
      onboardingCompletedAt: row.onboarding_completed_at
    }
  };
}

function mapBrokerConnection(row: BrokerConnectionRow): UserBrokerConnection {
  return {
    id: row.id,
    userId: row.user_id,
    broker: row.broker,
    accountLabel: row.account_label,
    environment: row.environment,
    status: row.status,
    permissions: row.permissions ?? [],
    managedBridgeId: row.managed_bridge_id,
    executionAccountRef: row.execution_account_ref,
    createdAt: row.created_at,
    lastSyncedAt: row.last_synced_at
  };
}

async function findUserByEmail(email: string): Promise<UserRow | null> {
  const normalized = normalizeEmail(email);
  const rows = await supabaseRequest<UserRow[]>(
    `alphapilot_users?select=*&email=eq.${encodeURIComponent(normalized)}&limit=1`
  );
  return rows?.[0] ?? runtimeUsers.find((user) => user.email === normalized) ?? null;
}

async function findUserById(id: string): Promise<UserRow | null> {
  const rows = await supabaseRequest<UserRow[]>(`alphapilot_users?select=*&id=eq.${encodeURIComponent(id)}&limit=1`);
  return rows?.[0] ?? runtimeUsers.find((user) => user.id === id) ?? null;
}

async function insertUser(row: UserRow) {
  const rows = await supabaseRequest<UserRow[]>("alphapilot_users", {
    method: "POST",
    body: JSON.stringify({
      id: row.id,
      email: row.email,
      password_hash: row.password_hash,
      password_salt: row.password_salt,
      display_name: row.display_name,
      automation_mode: row.automation_mode,
      base_currency: row.base_currency,
      risk_tolerance: row.risk_tolerance,
      markets: row.markets,
      onboarding_completed_at: row.onboarding_completed_at,
      created_at: row.created_at,
      updated_at: row.updated_at
    })
  });

  if (rows?.[0]) return rows[0];
  runtimeUsers.push(row);
  return row;
}

async function insertBrokerCredential(row: BrokerCredentialRow) {
  const rows = await supabaseRequest<BrokerCredentialRow[]>("alphapilot_broker_credentials", {
    method: "POST",
    body: JSON.stringify(row)
  });

  if (rows?.[0]) return rows[0];
  runtimeBrokerCredentials.push(row);
  return row;
}

async function findBrokerCredentialByConnectionId(connectionId: string) {
  const rows = await supabaseRequest<BrokerCredentialRow[]>(
    `alphapilot_broker_credentials?select=*&connection_id=eq.${encodeURIComponent(connectionId)}&limit=1`
  );
  return rows?.[0] ?? runtimeBrokerCredentials.find((credential) => credential.connection_id === connectionId) ?? null;
}

async function updateUserProfileRow(userId: string, profile: Partial<AlphaPilotUserProfile>): Promise<UserRow | null> {
  const now = new Date().toISOString();
  const patch = {
    display_name: profile.displayName,
    automation_mode: profile.automationMode,
    base_currency: profile.baseCurrency,
    risk_tolerance: profile.riskTolerance,
    markets: profile.markets,
    onboarding_completed_at: now,
    updated_at: now
  };

  const rows = await supabaseRequest<UserRow[]>(`alphapilot_users?id=eq.${encodeURIComponent(userId)}`, {
    method: "PATCH",
    body: JSON.stringify(patch)
  });

  if (rows?.[0]) return rows[0];

  const existing = runtimeUsers.find((user) => user.id === userId);
  if (!existing) return null;

  existing.display_name = patch.display_name ?? existing.display_name;
  existing.automation_mode = patch.automation_mode ?? existing.automation_mode;
  existing.base_currency = patch.base_currency ?? existing.base_currency;
  existing.risk_tolerance = patch.risk_tolerance ?? existing.risk_tolerance;
  existing.markets = patch.markets ?? existing.markets;
  existing.onboarding_completed_at = patch.onboarding_completed_at;
  existing.updated_at = patch.updated_at;
  return existing;
}

async function createSessionForUser(user: UserRow): Promise<AlphaPilotSession> {
  const token = generateSessionToken();
  const now = new Date();
  const row: SessionRow = {
    id: randomUUID(),
    user_id: user.id,
    token_hash: hashToken(token),
    expires_at: new Date(now.getTime() + sessionTtlMs).toISOString(),
    created_at: now.toISOString(),
    revoked_at: null
  };

  const rows = await supabaseRequest<SessionRow[]>("alphapilot_sessions", {
    method: "POST",
    body: JSON.stringify(row)
  });

  if (!rows?.[0]) runtimeSessions.push(row);

  return {
    token,
    expiresAt: row.expires_at,
    user: mapUser(user)
  };
}

export async function signUpAlphaPilotUser(input: { email?: unknown; password?: unknown; displayName?: unknown }) {
  if (typeof input.email !== "string" || !validateEmail(input.email)) {
    throw new Error("A valid email address is required.");
  }

  if (typeof input.password !== "string" || input.password.length < 8) {
    throw new Error("Password must be at least 8 characters.");
  }

  const email = normalizeEmail(input.email);
  const existing = await findUserByEmail(email);
  if (existing) throw new Error("An account already exists for this email.");

  const password = hashPassword(input.password);
  const now = new Date().toISOString();
  const user = await insertUser({
    id: randomUUID(),
    email,
    password_hash: password.hash,
    password_salt: password.salt,
    display_name: typeof input.displayName === "string" && input.displayName.trim() ? input.displayName.trim() : null,
    automation_mode: null,
    base_currency: "USD",
    risk_tolerance: "balanced",
    markets: [],
    onboarding_completed_at: null,
    created_at: now,
    updated_at: now
  });

  return createSessionForUser(user);
}

export async function loginAlphaPilotUser(input: { email?: unknown; password?: unknown }) {
  if (typeof input.email !== "string" || typeof input.password !== "string") {
    throw new Error("Email and password are required.");
  }

  const user = await findUserByEmail(input.email);
  if (!user || !verifyPassword(input.password, user)) {
    throw new Error("Invalid email or password.");
  }

  return createSessionForUser(user);
}

export function getSessionTokenFromRequest(request: Request) {
  const headerToken = request.headers.get("x-alphapilot-session-token");
  const authHeader = request.headers.get("authorization");
  const bearerToken = authHeader?.startsWith("Bearer ") ? authHeader.slice("Bearer ".length) : null;
  return headerToken || bearerToken;
}

export async function getAlphaPilotSession(request: Request): Promise<{ user: AlphaPilotUser; tokenHash: string } | null> {
  const token = getSessionTokenFromRequest(request);
  if (!token) return null;

  const tokenHash = hashToken(token);
  const rows = await supabaseRequest<SessionRow[]>(
    `alphapilot_sessions?select=*&token_hash=eq.${encodeURIComponent(tokenHash)}&revoked_at=is.null&limit=1`
  );
  const session = rows?.[0] ?? runtimeSessions.find((item) => item.token_hash === tokenHash && !item.revoked_at) ?? null;
  if (!session || new Date(session.expires_at).getTime() < Date.now()) return null;

  const user = await findUserById(session.user_id);
  return user ? { user: mapUser(user), tokenHash } : null;
}

export async function logoutAlphaPilotSession(request: Request) {
  const token = getSessionTokenFromRequest(request);
  if (!token) return false;

  const tokenHash = hashToken(token);
  const revokedAt = new Date().toISOString();
  const rows = await supabaseRequest<SessionRow[]>(`alphapilot_sessions?token_hash=eq.${encodeURIComponent(tokenHash)}`, {
    method: "PATCH",
    body: JSON.stringify({ revoked_at: revokedAt })
  });

  const runtime = runtimeSessions.find((session) => session.token_hash === tokenHash);
  if (runtime) runtime.revoked_at = revokedAt;

  return Boolean(rows?.[0] || runtime);
}

export async function setupAlphaPilotProfile(
  request: Request,
  input: {
    displayName?: unknown;
    automationMode?: unknown;
    baseCurrency?: unknown;
    riskTolerance?: unknown;
    markets?: unknown;
  }
) {
  const session = await getAlphaPilotSession(request);
  if (!session) throw new Error("Session is required.");

  const automationModes: UserAutomationMode[] = ["autopilot", "drive", "copilot"];
  const riskTolerances: UserRiskTolerance[] = ["conservative", "balanced", "aggressive"];
  const automationMode = automationModes.includes(input.automationMode as UserAutomationMode)
    ? (input.automationMode as UserAutomationMode)
    : "drive";
  const riskTolerance = riskTolerances.includes(input.riskTolerance as UserRiskTolerance)
    ? (input.riskTolerance as UserRiskTolerance)
    : "balanced";
  const markets = Array.isArray(input.markets)
    ? input.markets.filter((market): market is string => typeof market === "string").map((market) => market.trim()).filter(Boolean)
    : [];

  const row = await updateUserProfileRow(session.user.id, {
    displayName: typeof input.displayName === "string" && input.displayName.trim() ? input.displayName.trim() : null,
    automationMode,
    baseCurrency: typeof input.baseCurrency === "string" && input.baseCurrency.trim() ? input.baseCurrency.trim().toUpperCase() : "USD",
    riskTolerance,
    markets
  });

  if (!row) throw new Error("Profile could not be updated.");
  return mapUser(row);
}

export async function listUserBrokerConnections(request: Request) {
  const session = await getAlphaPilotSession(request);
  if (!session) throw new Error("Session is required.");

  const rows = await supabaseRequest<BrokerConnectionRow[]>(
    `alphapilot_broker_connections?select=*&user_id=eq.${encodeURIComponent(session.user.id)}&order=created_at.desc`
  );

  const fallback = runtimeBrokerConnections.filter((connection) => connection.user_id === session.user.id);
  return (rows ?? fallback).map(mapBrokerConnection);
}

export async function createUserBrokerConnection(
  request: Request,
  input: {
    broker?: unknown;
    accountLabel?: unknown;
    environment?: unknown;
    permissions?: unknown;
    secretRef?: unknown;
    credentials?: unknown;
  }
) {
  const session = await getAlphaPilotSession(request);
  if (!session) throw new Error("Session is required.");

  if (typeof input.broker !== "string" || !input.broker.trim()) {
    throw new Error("Broker is required.");
  }

  const now = new Date().toISOString();
  const connectionId = randomUUID();
  const credentialId =
    input.credentials && typeof input.credentials === "object" ? `cred_${randomUUID()}` : null;
  const row: BrokerConnectionRow = {
    id: connectionId,
    user_id: session.user.id,
    broker: input.broker.trim(),
    account_label: typeof input.accountLabel === "string" && input.accountLabel.trim() ? input.accountLabel.trim() : null,
    environment: input.environment === "live" ? "live" : "demo",
    status: "pending",
    permissions: Array.isArray(input.permissions)
      ? input.permissions.filter((permission): permission is string => typeof permission === "string").map((permission) => permission.trim()).filter(Boolean)
      : ["read_only"],
    managed_bridge_id: defaultManagedBridgeId,
    execution_account_ref: null,
    secret_ref: credentialId,
    created_at: now,
    last_synced_at: null
  };

  const rows = await supabaseRequest<BrokerConnectionRow[]>("alphapilot_broker_connections", {
    method: "POST",
    body: JSON.stringify({
      ...row,
      secret_ref: credentialId ?? (typeof input.secretRef === "string" ? input.secretRef : null)
    })
  });

  const storedConnection = rows?.[0] ?? row;
  if (!rows?.[0]) runtimeBrokerConnections.unshift(row);

  if (credentialId && input.credentials && typeof input.credentials === "object") {
    await insertBrokerCredential({
      id: credentialId,
      connection_id: storedConnection.id,
      user_id: session.user.id,
      managed_bridge_id: storedConnection.managed_bridge_id,
      ...encryptCredentialPayload(input.credentials),
      created_at: now,
      rotated_at: null
    });
  }

  void writeAuditEvent({
    userId: session.user.id,
    brokerConnectionId: storedConnection.id,
    actor: "user",
    eventType: "broker.connection_created",
    summary: `${storedConnection.broker} broker connection created.`,
    payload: {
      connection: mapBrokerConnection(storedConnection),
      hasEncryptedCredentials: Boolean(credentialId)
    }
  });

  return mapBrokerConnection(storedConnection);
}

export async function getUserBrokerConnectionForExecution(request: Request, brokerConnectionId?: unknown) {
  const session = await getAlphaPilotSession(request);
  if (!session) throw new Error("Session is required.");

  const rows = await supabaseRequest<BrokerConnectionRow[]>(
    `alphapilot_broker_connections?select=*&user_id=eq.${encodeURIComponent(session.user.id)}&order=created_at.desc`
  );
  const connections = rows ?? runtimeBrokerConnections.filter((connection) => connection.user_id === session.user.id);

  const requestedId = typeof brokerConnectionId === "string" && brokerConnectionId.trim() ? brokerConnectionId.trim() : null;
  const connection = requestedId
    ? connections.find((item) => item.id === requestedId)
    : connections.find((item) => item.status === "connected") ?? connections[0];

  if (!connection) {
    throw new Error("A broker connection is required before execution.");
  }

  return {
    user: session.user,
    connection: mapBrokerConnection(connection)
  };
}

export async function updateBrokerConnectionFromManagedBridge(
  connectionId: string,
  input: {
    status?: unknown;
    managedBridgeId?: unknown;
    executionAccountRef?: unknown;
  }
) {
  const statuses: BrokerConnectionStatus[] = ["pending", "connected", "failed", "revoked"];
  const status = statuses.includes(input.status as BrokerConnectionStatus)
    ? (input.status as BrokerConnectionStatus)
    : "connected";
  const now = new Date().toISOString();
  const patch = {
    status,
    managed_bridge_id:
      typeof input.managedBridgeId === "string" && input.managedBridgeId.trim()
        ? input.managedBridgeId.trim()
        : defaultManagedBridgeId,
    execution_account_ref:
      typeof input.executionAccountRef === "string" && input.executionAccountRef.trim()
        ? input.executionAccountRef.trim()
        : null,
    last_synced_at: now
  };

  const rows = await supabaseRequest<BrokerConnectionRow[]>(
    `alphapilot_broker_connections?id=eq.${encodeURIComponent(connectionId)}`,
    {
      method: "PATCH",
      body: JSON.stringify(patch)
    }
  );

  if (rows?.[0]) {
    void writeAuditEvent({
      userId: rows[0].user_id,
      brokerConnectionId: rows[0].id,
      actor: "bridge",
      eventType: `broker.connection_${rows[0].status}`,
      summary: `${rows[0].broker} broker connection marked ${rows[0].status}.`,
      payload: mapBrokerConnection(rows[0])
    });
    return mapBrokerConnection(rows[0]);
  }

  const runtime = runtimeBrokerConnections.find((connection) => connection.id === connectionId);
  if (!runtime) throw new Error("Broker connection was not found.");

  runtime.status = patch.status;
  runtime.managed_bridge_id = patch.managed_bridge_id;
  runtime.execution_account_ref = patch.execution_account_ref;
  runtime.last_synced_at = patch.last_synced_at;
  void writeAuditEvent({
    userId: runtime.user_id,
    brokerConnectionId: runtime.id,
    actor: "bridge",
    eventType: `broker.connection_${runtime.status}`,
    summary: `${runtime.broker} broker connection marked ${runtime.status}.`,
    payload: mapBrokerConnection(runtime)
  });
  return mapBrokerConnection(runtime);
}

export async function listManagedBridgeBrokerActivations(managedBridgeId: string, brokerFilter?: string | null) {
  const bridgeId = managedBridgeId.trim() || defaultManagedBridgeId;
  const normalizedBrokerFilter = brokerFilter?.trim().toLowerCase() ?? null;
  const rows = await supabaseRequest<BrokerConnectionRow[]>(
    `alphapilot_broker_connections?select=*&managed_bridge_id=eq.${encodeURIComponent(
      bridgeId
    )}&status=in.(pending,connected)&order=created_at.asc`
  );
  const connections =
    rows ??
    runtimeBrokerConnections.filter(
      (connection) =>
        connection.managed_bridge_id === bridgeId &&
        (connection.status === "pending" || connection.status === "connected")
    );
  const filteredConnections = normalizedBrokerFilter
    ? connections.filter((connection) => connection.broker.toLowerCase().includes(normalizedBrokerFilter))
    : connections;

  return Promise.all(
    filteredConnections.map(async (connection) => {
      const credential = await findBrokerCredentialByConnectionId(connection.id);
      return {
        connection: mapBrokerConnection(connection),
        credentials: credential ? decryptCredentialPayload(credential) : null
      };
    })
  );
}
