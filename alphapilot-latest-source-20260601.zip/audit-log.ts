import { randomUUID } from "node:crypto";
import type { AuditActor, AuditEvent } from "./types";
import { getAlphaPilotSession } from "./user-auth";

const supabaseUrl = process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

type AuditEventRow = {
  id: string;
  user_id: string | null;
  broker_connection_id: string | null;
  order_id: string | null;
  actor: AuditActor;
  event_type: string;
  summary: string;
  payload: unknown;
  created_at: string;
};

const runtimeAuditEvents: AuditEventRow[] = [];

function isSupabaseConfigured() {
  return Boolean(supabaseUrl && serviceRoleKey);
}

async function supabaseRequest<T>(path: string, init: RequestInit = {}): Promise<T | null> {
  if (!isSupabaseConfigured()) return null;

  try {
    const response = await fetch(`${supabaseUrl}/rest/v1/${path}`, {
      ...init,
      headers: {
        apikey: serviceRoleKey as string,
        Authorization: `Bearer ${serviceRoleKey}`,
        "Content-Type": "application/json",
        Prefer: "return=representation",
        ...init.headers
      },
      cache: "no-store"
    });

    if (response.ok) {
      if (response.status === 204) return null;
      return (await response.json()) as T;
    }
  } catch {
    return null;
  }

  return null;
}

function mapAuditEvent(row: AuditEventRow): AuditEvent {
  return {
    id: row.id,
    userId: row.user_id,
    brokerConnectionId: row.broker_connection_id,
    orderId: row.order_id,
    actor: row.actor,
    eventType: row.event_type,
    summary: row.summary,
    payload: row.payload,
    createdAt: row.created_at
  };
}

export async function writeAuditEvent(input: {
  userId?: string | null;
  brokerConnectionId?: string | null;
  orderId?: string | null;
  actor: AuditActor;
  eventType: string;
  summary: string;
  payload?: unknown;
}) {
  const row: AuditEventRow = {
    id: randomUUID(),
    user_id: input.userId ?? null,
    broker_connection_id: input.brokerConnectionId ?? null,
    order_id: input.orderId ?? null,
    actor: input.actor,
    event_type: input.eventType,
    summary: input.summary,
    payload: input.payload ?? {},
    created_at: new Date().toISOString()
  };

  const rows = await supabaseRequest<AuditEventRow[]>("alphapilot_audit_events", {
    method: "POST",
    body: JSON.stringify(row)
  });

  if (rows?.[0]) return mapAuditEvent(rows[0]);
  runtimeAuditEvents.unshift(row);
  runtimeAuditEvents.splice(500);
  return mapAuditEvent(row);
}

export async function listSignedInAuditEvents(request: Request, limit = 50) {
  const session = await getAlphaPilotSession(request);
  if (!session) throw new Error("Session is required.");

  const safeLimit = Math.min(Math.max(Math.trunc(limit), 1), 100);
  const rows = await supabaseRequest<AuditEventRow[]>(
    `alphapilot_audit_events?select=*&user_id=eq.${encodeURIComponent(
      session.user.id
    )}&order=created_at.desc&limit=${safeLimit}`
  );

  const fallback = runtimeAuditEvents.filter((event) => event.user_id === session.user.id).slice(0, safeLimit);
  return (rows ?? fallback).map(mapAuditEvent);
}
