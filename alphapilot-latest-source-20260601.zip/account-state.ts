import { randomUUID } from "node:crypto";
import { executionOrders } from "./seed";
import type { UserAccountSnapshot, UserPosition } from "./types";
import { getAlphaPilotSession } from "./user-auth";

const supabaseUrl = process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

type AccountSnapshotRow = {
  id: string;
  user_id: string;
  broker_connection_id: string;
  connector_id: string;
  managed_bridge_id: string;
  account_ref: string | null;
  currency: string | null;
  balance: number | null;
  equity: number | null;
  margin: number | null;
  free_margin: number | null;
  raw: unknown;
  reported_at: string;
};

type PositionRow = {
  id: string;
  user_id: string;
  broker_connection_id: string;
  connector_id: string;
  symbol: string;
  side: "long" | "short" | "unknown";
  size: number | null;
  entry_price: number | null;
  mark_price: number | null;
  pnl: number | null;
  raw: unknown;
  reported_at: string;
};

const runtimeSnapshots: AccountSnapshotRow[] = [];
const runtimePositions: PositionRow[] = [];

function isSupabaseConfigured() {
  return Boolean(supabaseUrl && serviceRoleKey);
}

async function supabaseRequest<T>(path: string, init: RequestInit = {}): Promise<T | null> {
  if (!isSupabaseConfigured()) return null;

  try {
    const response = await fetch(`${supabaseUrl}/rest/v1/${path}`, {
      ...init,
      headers: {
        apikey: serviceRoleKey as string,
        Authorization: `Bearer ${serviceRoleKey}`,
        "Content-Type": "application/json",
        Prefer: "return=representation",
        ...init.headers
      },
      cache: "no-store"
    });

    if (response.ok) {
      if (response.status === 204) return null;
      return (await response.json()) as T;
    }
  } catch {
    return null;
  }

  return null;
}

function mapSnapshot(row: AccountSnapshotRow): UserAccountSnapshot {
  return {
    id: row.id,
    userId: row.user_id,
    brokerConnectionId: row.broker_connection_id,
    connectorId: row.connector_id,
    managedBridgeId: row.managed_bridge_id,
    accountRef: row.account_ref,
    currency: row.currency,
    balance: row.balance,
    equity: row.equity,
    margin: row.margin,
    freeMargin: row.free_margin,
    raw: row.raw,
    reportedAt: row.reported_at
  };
}

function mapPosition(row: PositionRow): UserPosition {
  return {
    id: row.id,
    userId: row.user_id,
    brokerConnectionId: row.broker_connection_id,
    connectorId: row.connector_id,
    symbol: row.symbol,
    side: row.side,
    size: row.size,
    entryPrice: row.entry_price,
    markPrice: row.mark_price,
    pnl: row.pnl,
    raw: row.raw,
    reportedAt: row.reported_at
  };
}

function asNumber(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function asString(value: unknown) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function normalizeSide(value: unknown): "long" | "short" | "unknown" {
  if (value === "long" || value === "buy" || value === 0) return "long";
  if (value === "short" || value === "sell" || value === 1) return "short";
  return "unknown";
}

export async function reportManagedBridgeAccountState(input: {
  userId?: unknown;
  brokerConnectionId?: unknown;
  connectorId?: unknown;
  managedBridgeId?: unknown;
  accountRef?: unknown;
  account?: unknown;
  positions?: unknown;
  reportedAt?: unknown;
}) {
  if (typeof input.userId !== "string" || typeof input.brokerConnectionId !== "string") {
    throw new Error("userId and brokerConnectionId are required.");
  }

  const account = input.account && typeof input.account === "object" ? (input.account as Record<string, unknown>) : {};
  const reportedAt = typeof input.reportedAt === "string" ? input.reportedAt : new Date().toISOString();
  const connectorId = asString(input.connectorId) ?? "unknown";
  const managedBridgeId = asString(input.managedBridgeId) ?? "unknown";
  const snapshot: AccountSnapshotRow = {
    id: randomUUID(),
    user_id: input.userId,
    broker_connection_id: input.brokerConnectionId,
    connector_id: connectorId,
    managed_bridge_id: managedBridgeId,
    account_ref: asString(input.accountRef),
    currency: asString(account.currency) ?? asString(account.asset),
    balance: asNumber(account.balance) ?? asNumber(account.accountValue),
    equity: asNumber(account.equity) ?? asNumber(account.accountValue) ?? asNumber(account.marginSummary),
    margin: asNumber(account.margin),
    free_margin: asNumber(account.margin_free) ?? asNumber(account.freeMargin),
    raw: account,
    reported_at: reportedAt
  };

  const snapshotRows = await supabaseRequest<AccountSnapshotRow[]>("alphapilot_account_snapshots", {
    method: "POST",
    body: JSON.stringify(snapshot)
  });
  if (!snapshotRows?.[0]) runtimeSnapshots.unshift(snapshot);

  const sourcePositions = Array.isArray(input.positions) ? input.positions : [];
  const positions = sourcePositions.map((position): PositionRow => {
    const row = position && typeof position === "object" ? (position as Record<string, unknown>) : {};
    const symbol = asString(row.symbol) ?? asString(row.coin) ?? "UNKNOWN";
    return {
      id: randomUUID(),
      user_id: input.userId as string,
      broker_connection_id: input.brokerConnectionId as string,
      connector_id: connectorId,
      symbol,
      side: normalizeSide(row.side ?? row.type),
      size: asNumber(row.volume) ?? asNumber(row.size) ?? asNumber(row.szi),
      entry_price: asNumber(row.price_open) ?? asNumber(row.entryPrice),
      mark_price: asNumber(row.markPrice) ?? asNumber(row.positionValue),
      pnl: asNumber(row.profit) ?? asNumber(row.unrealizedPnl),
      raw: row,
      reported_at: reportedAt
    };
  });

  if (positions.length) {
    const positionRows = await supabaseRequest<PositionRow[]>("alphapilot_positions", {
      method: "POST",
      body: JSON.stringify(positions)
    });
    if (!positionRows?.length) runtimePositions.unshift(...positions);
  }

  return {
    snapshot: mapSnapshot(snapshotRows?.[0] ?? snapshot),
    positions: positions.map(mapPosition)
  };
}

export async function getUserAccountState(request: Request) {
  const session = await getAlphaPilotSession(request);
  if (!session) throw new Error("Session is required.");

  const snapshotRows = await supabaseRequest<AccountSnapshotRow[]>(
    `alphapilot_account_snapshots?select=*&user_id=eq.${encodeURIComponent(
      session.user.id
    )}&order=reported_at.desc&limit=20`
  );
  const positionRows = await supabaseRequest<PositionRow[]>(
    `alphapilot_positions?select=*&user_id=eq.${encodeURIComponent(
      session.user.id
    )}&order=reported_at.desc&limit=100`
  );

  const snapshots = snapshotRows ?? runtimeSnapshots.filter((snapshot) => snapshot.user_id === session.user.id);
  const positions = positionRows ?? runtimePositions.filter((position) => position.user_id === session.user.id);
  const orders = executionOrders.filter((order) => order.userId === session.user.id);

  return {
    user: session.user,
    latestSnapshot: snapshots[0] ? mapSnapshot(snapshots[0]) : null,
    snapshots: snapshots.map(mapSnapshot),
    positions: positions.map(mapPosition),
    executionOrders: orders
  };
}
