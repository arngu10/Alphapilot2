import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { listSignedInAuditEvents } from "@/lib/backend/audit-log";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const limit = Number(url.searchParams.get("limit") ?? 50);
    return ok({ events: await listSignedInAuditEvents(request, limit) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Audit events could not be loaded.";
    return message === "Session is required." ? unauthorized("session required") : badRequest(message);
  }
}
