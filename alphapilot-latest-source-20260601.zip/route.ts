import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { getMeOverview } from "@/lib/backend/me-overview";

export async function GET(request: Request) {
  try {
    return ok({ overview: await getMeOverview(request) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Overview could not be loaded.";
    return message === "Session is required." ? unauthorized("session required") : badRequest(message);
  }
}
