import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { reportManagedBridgeAccountState } from "@/lib/backend/account-state";
import { isBridgeRequestAuthorized } from "@/lib/backend/auth";

export async function POST(request: Request) {
  if (!isBridgeRequestAuthorized(request)) {
    return unauthorized("invalid bridge token");
  }

  try {
    const body = await request.json();
    return ok(await reportManagedBridgeAccountState(body));
  } catch (error) {
    return badRequest(error instanceof Error ? error.message : "Account state could not be stored.");
  }
}
