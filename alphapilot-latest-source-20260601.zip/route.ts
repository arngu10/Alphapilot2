import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { areAppWritesProtected, isAppRequestAuthorized, isBridgeRequestAuthorized } from "@/lib/backend/auth";
import { submitExecutionOrderFromPlan, listExecutionOrders, reportExecutionOrder } from "@/lib/backend/execution-engine";
import { getAlphaPilotSession, getUserBrokerConnectionForExecution } from "@/lib/backend/user-auth";
import type { DrivePlan, ExecutionOrderStatus } from "@/lib/backend/types";

const orderStatuses = new Set<ExecutionOrderStatus>(["queued", "sent", "filled", "rejected", "cancelled", "dry_run"]);

function parseLimit(value: string | null) {
  const numberValue = value ? Number(value) : 25;
  return Number.isFinite(numberValue) ? Math.min(Math.max(Math.trunc(numberValue), 1), 100) : 25;
}

function parseStatus(value: string | null) {
  return value && orderStatuses.has(value as ExecutionOrderStatus) ? (value as ExecutionOrderStatus) : undefined;
}

export async function GET(request: Request) {
  const session = await getAlphaPilotSession(request);
  const url = new URL(request.url);

  if (session) {
    return ok({
      orders: listExecutionOrders(parseLimit(url.searchParams.get("limit")), parseStatus(url.searchParams.get("status")), {
        userId: session.user.id
      })
    });
  }

  const appAuthorized = areAppWritesProtected() && isAppRequestAuthorized(request);
  if (!isBridgeRequestAuthorized(request) && !appAuthorized) {
    return unauthorized("invalid execution token");
  }

  const managedBridgeId = request.headers.get("x-alphapilot-bridge-id") ?? process.env.ALPHAPILOT_MANAGED_BRIDGE_ID ?? "alphapilot-managed-vps-1";
  return ok({
    orders: listExecutionOrders(parseLimit(url.searchParams.get("limit")), parseStatus(url.searchParams.get("status")), {
      managedBridgeId: appAuthorized ? url.searchParams.get("managedBridgeId") : managedBridgeId
    })
  });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as {
    plan?: unknown;
    dryRun?: unknown;
    source?: unknown;
    report?: unknown;
    brokerConnectionId?: unknown;
  };

  try {
    if (body.report && typeof body.report === "object") {
      if (!isBridgeRequestAuthorized(request)) {
        return unauthorized("invalid bridge token");
      }

      const report = body.report as {
        id?: unknown;
        status?: unknown;
        ticket?: unknown;
        retcode?: unknown;
        comment?: unknown;
        raw?: unknown;
      };

      if (typeof report.id !== "string") return badRequest("report.id is required");
      if (typeof report.status !== "string" || !orderStatuses.has(report.status as ExecutionOrderStatus)) {
        return badRequest("report.status is invalid");
      }

      return ok({
        order: await reportExecutionOrder({
          id: report.id,
          status: report.status as ExecutionOrderStatus,
          ticket: typeof report.ticket === "number" ? report.ticket : null,
          retcode: typeof report.retcode === "number" ? report.retcode : null,
          comment: typeof report.comment === "string" ? report.comment : null,
          raw: report.raw
        })
      });
    }

    const session = await getAlphaPilotSession(request);
    const appAuthorized = areAppWritesProtected() && isAppRequestAuthorized(request);

    if (!session && !appAuthorized) {
      return unauthorized("invalid app token");
    }

    if (!body.plan || typeof body.plan !== "object") {
      return badRequest("plan is required");
    }

    const routing = session
      ? await getUserBrokerConnectionForExecution(request, body.brokerConnectionId)
      : null;

    const order = await submitExecutionOrderFromPlan({
      plan: body.plan as DrivePlan,
      dryRun: body.dryRun !== false,
      source: body.source === "drive" || body.source === "automation" ? body.source : "operator",
      userId: routing?.user.id ?? null,
      brokerConnectionId: routing?.connection.id ?? null,
      connectorId: routing?.connection.broker.toLowerCase().includes("hyperliquid") ? "hyperliquid" : "vantage-mt5",
      managedBridgeId: routing?.connection.managedBridgeId ?? null,
      brokerAccountRef: routing?.connection.executionAccountRef ?? null,
      brokerConnectionStatus: routing?.connection.status ?? null
    });

    return ok({
      order
    });
  } catch (error) {
    return badRequest(error instanceof Error ? error.message : "Execution order could not be processed");
  }
}
