import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { getAlphaPilotSession, setupAlphaPilotProfile } from "@/lib/backend/user-auth";

export async function GET(request: Request) {
  const session = await getAlphaPilotSession(request);
  if (!session) return unauthorized("session required");

  return ok({ user: session.user });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const user = await setupAlphaPilotProfile(request, body);
    return ok({ user });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not update profile.";
    return message === "Session is required." ? unauthorized("session required") : badRequest(message);
  }
}
