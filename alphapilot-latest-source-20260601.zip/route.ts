import { ok, unauthorized } from "@/lib/backend/api-response";
import { getAlphaPilotSession } from "@/lib/backend/user-auth";

export async function GET(request: Request) {
  const session = await getAlphaPilotSession(request);
  if (!session) return unauthorized("session required");

  return ok({ user: session.user });
}
