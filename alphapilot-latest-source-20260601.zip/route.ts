import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { isAppRequestAuthorized, isBridgeRequestAuthorized } from "@/lib/backend/auth";
import { updateBrokerConnectionFromManagedBridge } from "@/lib/backend/user-auth";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!isBridgeRequestAuthorized(request) && !isAppRequestAuthorized(request)) {
    return unauthorized("invalid bridge token");
  }

  try {
    const { id } = await context.params;
    const body = await request.json();
    const connection = await updateBrokerConnectionFromManagedBridge(id, {
      ...body,
      managedBridgeId: body?.managedBridgeId ?? request.headers.get("x-alphapilot-bridge-id")
    });

    return ok({ connection });
  } catch (error) {
    return badRequest(error instanceof Error ? error.message : "Broker connection could not be updated.");
  }
}
