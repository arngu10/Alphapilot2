import { badRequest, ok } from "@/lib/backend/api-response";
import { loginAlphaPilotUser } from "@/lib/backend/user-auth";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const session = await loginAlphaPilotUser(body);
    return ok(session);
  } catch (error) {
    return badRequest(error instanceof Error ? error.message : "Could not log in.");
  }
}
