import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { writeAuditEvent } from "@/lib/backend/audit-log";
import { isAppRequestAuthorized } from "@/lib/backend/auth";
import { executionState } from "@/lib/backend/seed";
import { getAlphaPilotSession } from "@/lib/backend/user-auth";
import { getSignedInUserRisk, updateSignedInUserRisk } from "@/lib/backend/user-risk";

export async function GET(request: Request) {
  if (await getAlphaPilotSession(request)) {
    const risk = await getSignedInUserRisk(request);
    return ok({
      active: risk.settings.userKillSwitchActive,
      settings: risk.settings,
      checks: risk.checks
    });
  }

  return ok({
    active: executionState.killSwitchActive
  });
}

export async function POST(request: Request) {
  if (await getAlphaPilotSession(request)) {
    try {
      const body = (await request.json()) as { active?: boolean; brokerConnectionId?: string };
      const current = await getSignedInUserRisk(request);
      const brokerKillSwitches = { ...current.settings.brokerKillSwitches };
      if (body.brokerConnectionId) brokerKillSwitches[body.brokerConnectionId] = Boolean(body.active);

      const risk = await updateSignedInUserRisk(request, {
        userKillSwitchActive: body.brokerConnectionId ? current.settings.userKillSwitchActive : Boolean(body.active),
        brokerKillSwitches
      });

      void writeAuditEvent({
        userId: current.user.id,
        brokerConnectionId: body.brokerConnectionId ?? null,
        actor: "user",
        eventType: body.brokerConnectionId ? "risk.broker_kill_switch_changed" : "risk.user_kill_switch_changed",
        summary: body.brokerConnectionId
          ? `Broker kill switch set to ${Boolean(body.active)}.`
          : `User kill switch set to ${Boolean(body.active)}.`,
        payload: risk.settings
      });

      return ok({
        active: risk.settings.userKillSwitchActive,
        settings: risk.settings,
        checks: risk.checks
      });
    } catch (error) {
      return badRequest(error instanceof Error ? error.message : "User kill switch could not be updated.");
    }
  }

  if (!isAppRequestAuthorized(request)) {
    return unauthorized("invalid app token");
  }

  const body = (await request.json()) as { active?: boolean };
  executionState.killSwitchActive = Boolean(body.active);

  if (executionState.killSwitchActive) {
    executionState.mode = "copilot";
    executionState.automationLocked = true;
    if (!executionState.lockReasons.includes("Kill switch is active")) {
      executionState.lockReasons.push("Kill switch is active");
    }
  }

  void writeAuditEvent({
    actor: "admin",
    eventType: "risk.global_kill_switch_changed",
    summary: `Global kill switch set to ${executionState.killSwitchActive}.`,
    payload: executionState
  });

  return ok(executionState);
}
