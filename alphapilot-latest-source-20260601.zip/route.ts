import { badRequest, ok } from "@/lib/backend/api-response";
import { signUpAlphaPilotUser } from "@/lib/backend/user-auth";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const session = await signUpAlphaPilotUser(body);
    return ok(session);
  } catch (error) {
    return badRequest(error instanceof Error ? error.message : "Could not create account.");
  }
}
