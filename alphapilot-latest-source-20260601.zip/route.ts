import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { getUserAccountState } from "@/lib/backend/account-state";

export async function GET(request: Request) {
  try {
    return ok(await getUserAccountState(request));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Account state could not be loaded.";
    return message === "Session is required." ? unauthorized("session required") : badRequest(message);
  }
}
