import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { isBridgeRequestAuthorized } from "@/lib/backend/auth";
import { writeAuditEvent } from "@/lib/backend/audit-log";

export async function POST(request: Request) {
  if (!isBridgeRequestAuthorized(request)) {
    return unauthorized("invalid bridge token");
  }

  try {
    const body = await request.json();
    const event = await writeAuditEvent({
      userId: typeof body.userId === "string" ? body.userId : null,
      brokerConnectionId: typeof body.brokerConnectionId === "string" ? body.brokerConnectionId : null,
      orderId: typeof body.orderId === "string" ? body.orderId : null,
      actor: "bridge",
      eventType: typeof body.eventType === "string" ? body.eventType : "bridge.event",
      summary: typeof body.summary === "string" ? body.summary : "Bridge audit event recorded.",
      payload: body.payload ?? {}
    });

    return ok({ event });
  } catch (error) {
    return badRequest(error instanceof Error ? error.message : "Audit event could not be stored.");
  }
}
