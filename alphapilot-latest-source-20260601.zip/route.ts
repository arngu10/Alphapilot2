import { ok } from "@/lib/backend/api-response";
import { logoutAlphaPilotSession } from "@/lib/backend/user-auth";

export async function POST(request: Request) {
  const loggedOut = await logoutAlphaPilotSession(request);
  return ok({ loggedOut });
}
