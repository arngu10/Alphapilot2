import { badRequest, ok, unauthorized } from "@/lib/backend/api-response";
import { createUserBrokerConnection, listUserBrokerConnections } from "@/lib/backend/user-auth";

export async function GET(request: Request) {
  try {
    const connections = await listUserBrokerConnections(request);
    return ok({ connections });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not list broker connections.";
    return message === "Session is required." ? unauthorized("session required") : badRequest(message);
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const connection = await createUserBrokerConnection(request, body);
    return ok({ connection });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not create broker connection.";
    return message === "Session is required." ? unauthorized("session required") : badRequest(message);
  }
}
