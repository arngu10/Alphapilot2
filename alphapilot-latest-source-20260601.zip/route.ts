import { ok, unauthorized } from "@/lib/backend/api-response";
import { isBridgeRequestAuthorized } from "@/lib/backend/auth";
import { listManagedBridgeBrokerActivations } from "@/lib/backend/user-auth";

export async function GET(request: Request) {
  if (!isBridgeRequestAuthorized(request)) {
    return unauthorized("invalid bridge token");
  }

  const url = new URL(request.url);
  const managedBridgeId =
    request.headers.get("x-alphapilot-bridge-id") ??
    url.searchParams.get("managedBridgeId") ??
    process.env.ALPHAPILOT_MANAGED_BRIDGE_ID ??
    "alphapilot-managed-vps-1";
  const broker = url.searchParams.get("broker");

  return ok({
    managedBridgeId,
    activations: await listManagedBridgeBrokerActivations(managedBridgeId, broker)
  });
}
