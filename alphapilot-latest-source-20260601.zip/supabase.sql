-- AlphaPilot MVP persistence.
-- Run this in Supabase SQL Editor once per project.

create table if not exists public.mt5_heartbeats (
  id uuid primary key default gen_random_uuid(),
  connector_id text not null default 'vantage-mt5',
  ok boolean not null,
  reported_at timestamptz not null,
  received_at timestamptz not null default now(),
  account jsonb,
  symbols jsonb not null default '[]'::jsonb,
  candles jsonb not null default '[]'::jsonb,
  positions jsonb not null default '[]'::jsonb,
  last_error jsonb
);

alter table public.mt5_heartbeats
  add column if not exists candles jsonb not null default '[]'::jsonb;

create index if not exists mt5_heartbeats_reported_at_idx
  on public.mt5_heartbeats (reported_at desc);

create table if not exists public.drive_plans (
  id text primary key,
  symbol text not null,
  side text not null check (side in ('long', 'short')),
  status text not null,
  score numeric not null,
  confidence text not null,
  entry jsonb not null,
  stop_loss numeric not null,
  targets jsonb not null default '[]'::jsonb,
  risk_pct numeric not null,
  reward_risk numeric not null,
  source text not null,
  rationale jsonb not null default '[]'::jsonb,
  risk_notes jsonb not null default '[]'::jsonb,
  created_at timestamptz not null
);

create index if not exists drive_plans_created_at_idx
  on public.drive_plans (created_at desc);

create table if not exists public.journal_entries (
  id uuid primary key default gen_random_uuid(),
  drive_plan_id text references public.drive_plans(id) on delete set null,
  symbol text not null,
  note text not null,
  outcome text,
  created_at timestamptz not null default now()
);

create index if not exists journal_entries_created_at_idx
  on public.journal_entries (created_at desc);

create table if not exists public.economic_events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  currency text not null,
  impact text not null check (impact in ('low', 'medium', 'high')),
  starts_at timestamptz not null,
  source text not null default 'manual' check (source in ('manual', 'fred', 'gdelt', 'provider')),
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists economic_events_starts_at_idx
  on public.economic_events (starts_at asc);

create index if not exists economic_events_currency_starts_at_idx
  on public.economic_events (currency, starts_at asc);

create table if not exists public.scanner_snapshots (
  id uuid primary key default gen_random_uuid(),
  generated_at timestamptz not null,
  received_at timestamptz not null default now(),
  online boolean not null default false,
  session_name text not null,
  priority_symbol text,
  priority_score numeric,
  providers jsonb not null default '[]'::jsonb,
  analysis jsonb not null
);

create index if not exists scanner_snapshots_generated_at_idx
  on public.scanner_snapshots (generated_at desc);

create index if not exists scanner_snapshots_priority_idx
  on public.scanner_snapshots (priority_symbol, generated_at desc);

create table if not exists public.decision_journal (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('scanner', 'copilot', 'drive', 'automation', 'risk')),
  symbol text,
  status text not null check (status in ('accepted', 'blocked', 'info', 'error')),
  summary text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists decision_journal_created_at_idx
  on public.decision_journal (created_at desc);

create index if not exists decision_journal_kind_symbol_idx
  on public.decision_journal (kind, symbol, created_at desc);

create table if not exists public.alphapilot_users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  password_hash text not null,
  password_salt text not null,
  display_name text,
  automation_mode text check (automation_mode in ('autopilot', 'drive', 'copilot')),
  base_currency text not null default 'USD',
  risk_tolerance text not null default 'balanced' check (risk_tolerance in ('conservative', 'balanced', 'aggressive')),
  markets jsonb not null default '[]'::jsonb,
  onboarding_completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists alphapilot_users_email_idx
  on public.alphapilot_users (email);

create table if not exists public.alphapilot_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.alphapilot_users(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  revoked_at timestamptz
);

create index if not exists alphapilot_sessions_token_hash_idx
  on public.alphapilot_sessions (token_hash);

create index if not exists alphapilot_sessions_user_expires_idx
  on public.alphapilot_sessions (user_id, expires_at desc);

create table if not exists public.alphapilot_broker_connections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.alphapilot_users(id) on delete cascade,
  broker text not null,
  account_label text,
  environment text not null default 'demo' check (environment in ('demo', 'live')),
  status text not null default 'pending' check (status in ('pending', 'connected', 'failed', 'revoked')),
  permissions jsonb not null default '["read_only"]'::jsonb,
  managed_bridge_id text not null default 'alphapilot-managed-vps-1',
  execution_account_ref text,
  secret_ref text,
  created_at timestamptz not null default now(),
  last_synced_at timestamptz
);

alter table public.alphapilot_broker_connections
  add column if not exists managed_bridge_id text not null default 'alphapilot-managed-vps-1';

alter table public.alphapilot_broker_connections
  add column if not exists execution_account_ref text;

create index if not exists alphapilot_broker_connections_user_idx
  on public.alphapilot_broker_connections (user_id, created_at desc);

create index if not exists alphapilot_broker_connections_bridge_idx
  on public.alphapilot_broker_connections (managed_bridge_id, status);

create table if not exists public.alphapilot_broker_credentials (
  id text primary key,
  connection_id uuid not null references public.alphapilot_broker_connections(id) on delete cascade,
  user_id uuid not null references public.alphapilot_users(id) on delete cascade,
  managed_bridge_id text not null,
  encrypted_payload text not null,
  iv text not null,
  auth_tag text not null,
  created_at timestamptz not null default now(),
  rotated_at timestamptz
);

create unique index if not exists alphapilot_broker_credentials_connection_idx
  on public.alphapilot_broker_credentials (connection_id);

create index if not exists alphapilot_broker_credentials_bridge_idx
  on public.alphapilot_broker_credentials (managed_bridge_id);

create table if not exists public.alphapilot_account_snapshots (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.alphapilot_users(id) on delete cascade,
  broker_connection_id uuid not null references public.alphapilot_broker_connections(id) on delete cascade,
  connector_id text not null,
  managed_bridge_id text not null,
  account_ref text,
  currency text,
  balance numeric,
  equity numeric,
  margin numeric,
  free_margin numeric,
  raw jsonb not null default '{}'::jsonb,
  reported_at timestamptz not null
);

create index if not exists alphapilot_account_snapshots_user_idx
  on public.alphapilot_account_snapshots (user_id, reported_at desc);

create index if not exists alphapilot_account_snapshots_connection_idx
  on public.alphapilot_account_snapshots (broker_connection_id, reported_at desc);

create table if not exists public.alphapilot_positions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.alphapilot_users(id) on delete cascade,
  broker_connection_id uuid not null references public.alphapilot_broker_connections(id) on delete cascade,
  connector_id text not null,
  symbol text not null,
  side text not null default 'unknown' check (side in ('long', 'short', 'unknown')),
  size numeric,
  entry_price numeric,
  mark_price numeric,
  pnl numeric,
  raw jsonb not null default '{}'::jsonb,
  reported_at timestamptz not null
);

create index if not exists alphapilot_positions_user_idx
  on public.alphapilot_positions (user_id, reported_at desc);

create index if not exists alphapilot_positions_connection_symbol_idx
  on public.alphapilot_positions (broker_connection_id, symbol, reported_at desc);

create table if not exists public.alphapilot_user_risk_settings (
  user_id uuid primary key references public.alphapilot_users(id) on delete cascade,
  max_risk_per_trade_pct numeric not null default 0.5,
  max_daily_loss_pct numeric not null default 3,
  max_open_positions integer not null default 5,
  allowed_symbols jsonb not null default '["XAUUSD","EURUSD","GBPUSD","BTCUSDT","ETHUSDT"]'::jsonb,
  automation_enabled boolean not null default false,
  user_kill_switch_active boolean not null default false,
  broker_kill_switches jsonb not null default '{}'::jsonb,
  daily_loss_lockout_active boolean not null default false,
  updated_at timestamptz not null default now()
);

create table if not exists public.alphapilot_audit_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.alphapilot_users(id) on delete set null,
  broker_connection_id uuid references public.alphapilot_broker_connections(id) on delete set null,
  order_id text,
  actor text not null check (actor in ('user', 'automation', 'bridge', 'system', 'admin')),
  event_type text not null,
  summary text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists alphapilot_audit_events_user_idx
  on public.alphapilot_audit_events (user_id, created_at desc);

create index if not exists alphapilot_audit_events_order_idx
  on public.alphapilot_audit_events (order_id, created_at desc);

create index if not exists alphapilot_audit_events_type_idx
  on public.alphapilot_audit_events (event_type, created_at desc);

alter table public.mt5_heartbeats enable row level security;
alter table public.drive_plans enable row level security;
alter table public.journal_entries enable row level security;
alter table public.economic_events enable row level security;
alter table public.scanner_snapshots enable row level security;
alter table public.decision_journal enable row level security;
alter table public.alphapilot_users enable row level security;
alter table public.alphapilot_sessions enable row level security;
alter table public.alphapilot_broker_connections enable row level security;
alter table public.alphapilot_broker_credentials enable row level security;
alter table public.alphapilot_account_snapshots enable row level security;
alter table public.alphapilot_positions enable row level security;
alter table public.alphapilot_user_risk_settings enable row level security;
alter table public.alphapilot_audit_events enable row level security;
