import type { RiskCheck, UserRiskSettings } from "./types";
import { getUserAccountState } from "./account-state";
import { writeAuditEvent } from "./audit-log";
import { getAlphaPilotSession } from "./user-auth";

const supabaseUrl = process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

type UserRiskSettingsRow = {
  user_id: string;
  max_risk_per_trade_pct: number;
  max_daily_loss_pct: number;
  max_open_positions: number;
  allowed_symbols: string[];
  automation_enabled: boolean;
  user_kill_switch_active: boolean;
  broker_kill_switches: Record<string, boolean>;
  daily_loss_lockout_active: boolean;
  updated_at: string;
};

const runtimeUserRiskSettings: UserRiskSettingsRow[] = [];

function isSupabaseConfigured() {
  return Boolean(supabaseUrl && serviceRoleKey);
}

async function supabaseRequest<T>(path: string, init: RequestInit = {}): Promise<T | null> {
  if (!isSupabaseConfigured()) return null;

  try {
    const response = await fetch(`${supabaseUrl}/rest/v1/${path}`, {
      ...init,
      headers: {
        apikey: serviceRoleKey as string,
        Authorization: `Bearer ${serviceRoleKey}`,
        "Content-Type": "application/json",
        Prefer: "return=representation",
        ...init.headers
      },
      cache: "no-store"
    });

    if (response.ok) {
      if (response.status === 204) return null;
      return (await response.json()) as T;
    }
  } catch {
    return null;
  }

  return null;
}

function defaultUserRiskSettings(userId: string): UserRiskSettingsRow {
  return {
    user_id: userId,
    max_risk_per_trade_pct: 0.5,
    max_daily_loss_pct: 3,
    max_open_positions: 5,
    allowed_symbols: ["XAUUSD", "EURUSD", "GBPUSD", "BTCUSDT", "ETHUSDT"],
    automation_enabled: false,
    user_kill_switch_active: false,
    broker_kill_switches: {},
    daily_loss_lockout_active: false,
    updated_at: new Date().toISOString()
  };
}

function mapSettings(row: UserRiskSettingsRow): UserRiskSettings {
  return {
    userId: row.user_id,
    maxRiskPerTradePct: row.max_risk_per_trade_pct,
    maxDailyLossPct: row.max_daily_loss_pct,
    maxOpenPositions: row.max_open_positions,
    allowedSymbols: row.allowed_symbols ?? [],
    automationEnabled: row.automation_enabled,
    userKillSwitchActive: row.user_kill_switch_active,
    brokerKillSwitches: row.broker_kill_switches ?? {},
    dailyLossLockoutActive: row.daily_loss_lockout_active,
    updatedAt: row.updated_at
  };
}

function rowFromPatch(userId: string, patch: Partial<UserRiskSettings>, existing?: UserRiskSettingsRow): UserRiskSettingsRow {
  const base = existing ?? defaultUserRiskSettings(userId);
  return {
    ...base,
    max_risk_per_trade_pct: patch.maxRiskPerTradePct ?? base.max_risk_per_trade_pct,
    max_daily_loss_pct: patch.maxDailyLossPct ?? base.max_daily_loss_pct,
    max_open_positions: patch.maxOpenPositions ?? base.max_open_positions,
    allowed_symbols: patch.allowedSymbols ?? base.allowed_symbols,
    automation_enabled: patch.automationEnabled ?? base.automation_enabled,
    user_kill_switch_active: patch.userKillSwitchActive ?? base.user_kill_switch_active,
    broker_kill_switches: patch.brokerKillSwitches ?? base.broker_kill_switches,
    daily_loss_lockout_active: patch.dailyLossLockoutActive ?? base.daily_loss_lockout_active,
    updated_at: new Date().toISOString()
  };
}

async function findSettingsRow(userId: string) {
  const rows = await supabaseRequest<UserRiskSettingsRow[]>(
    `alphapilot_user_risk_settings?select=*&user_id=eq.${encodeURIComponent(userId)}&limit=1`
  );
  return rows?.[0] ?? runtimeUserRiskSettings.find((settings) => settings.user_id === userId) ?? null;
}

async function upsertSettingsRow(row: UserRiskSettingsRow) {
  const rows = await supabaseRequest<UserRiskSettingsRow[]>("alphapilot_user_risk_settings", {
    method: "POST",
    headers: {
      Prefer: "resolution=merge-duplicates,return=representation"
    },
    body: JSON.stringify(row)
  });

  if (rows?.[0]) return rows[0];

  const index = runtimeUserRiskSettings.findIndex((settings) => settings.user_id === row.user_id);
  if (index >= 0) runtimeUserRiskSettings[index] = row;
  else runtimeUserRiskSettings.push(row);
  return row;
}

export async function getUserRiskSettings(userId: string) {
  const row = (await findSettingsRow(userId)) ?? (await upsertSettingsRow(defaultUserRiskSettings(userId)));
  return mapSettings(row);
}

export async function getSignedInUserRisk(request: Request) {
  const session = await getAlphaPilotSession(request);
  if (!session) throw new Error("Session is required.");

  const settings = await getUserRiskSettings(session.user.id);
  const accountState = await getUserAccountState(request);
  return {
    user: session.user,
    settings,
    checks: buildUserRiskChecks(settings, accountState.positions, accountState.executionOrders)
  };
}

export async function updateSignedInUserRisk(request: Request, input: Partial<UserRiskSettings>) {
  const session = await getAlphaPilotSession(request);
  if (!session) throw new Error("Session is required.");

  const existing = await findSettingsRow(session.user.id);
  const row = rowFromPatch(session.user.id, sanitizePatch(input), existing ?? undefined);
  const saved = await upsertSettingsRow(row);
  const settings = mapSettings(saved);
  const accountState = await getUserAccountState(request);
  void writeAuditEvent({
    userId: session.user.id,
    actor: "user",
    eventType: "risk.settings_updated",
    summary: "User risk settings updated.",
    payload: settings
  });

  return {
    user: session.user,
    settings,
    checks: buildUserRiskChecks(settings, accountState.positions, accountState.executionOrders)
  };
}

function sanitizePatch(input: Partial<UserRiskSettings>) {
  const patch: Partial<UserRiskSettings> = {};
  if (typeof input.maxRiskPerTradePct === "number" && input.maxRiskPerTradePct > 0 && input.maxRiskPerTradePct <= 5) {
    patch.maxRiskPerTradePct = input.maxRiskPerTradePct;
  }
  if (typeof input.maxDailyLossPct === "number" && input.maxDailyLossPct > 0 && input.maxDailyLossPct <= 20) {
    patch.maxDailyLossPct = input.maxDailyLossPct;
  }
  if (Number.isInteger(input.maxOpenPositions) && (input.maxOpenPositions as number) >= 1 && (input.maxOpenPositions as number) <= 25) {
    patch.maxOpenPositions = input.maxOpenPositions;
  }
  if (Array.isArray(input.allowedSymbols)) {
    patch.allowedSymbols = input.allowedSymbols.filter((symbol): symbol is string => typeof symbol === "string").map((symbol) => symbol.trim().toUpperCase()).filter(Boolean);
  }
  if (typeof input.automationEnabled === "boolean") patch.automationEnabled = input.automationEnabled;
  if (typeof input.userKillSwitchActive === "boolean") patch.userKillSwitchActive = input.userKillSwitchActive;
  if (typeof input.dailyLossLockoutActive === "boolean") patch.dailyLossLockoutActive = input.dailyLossLockoutActive;
  if (input.brokerKillSwitches && typeof input.brokerKillSwitches === "object") {
    patch.brokerKillSwitches = Object.fromEntries(
      Object.entries(input.brokerKillSwitches).filter((entry): entry is [string, boolean] => typeof entry[0] === "string" && typeof entry[1] === "boolean")
    );
  }
  return patch;
}

export function buildUserRiskChecks(
  settings: UserRiskSettings,
  positions: Array<{ symbol: string; pnl: number | null }>,
  orders: Array<{ status: string; riskPct: number; brokerConnectionId: string | null }>
): RiskCheck[] {
  const openPositions = positions.length;
  const openOrders = orders.filter((order) => order.status === "queued" || order.status === "sent").length;
  const dailyPnlPct = 0;
  const brokerKillActive = Object.values(settings.brokerKillSwitches).some(Boolean);

  return [
    {
      code: "user_kill_switch",
      label: "User kill switch",
      status: settings.userKillSwitchActive ? "fail" : "pass",
      detail: settings.userKillSwitchActive ? "User-level kill switch is active." : "User-level kill switch is clear."
    },
    {
      code: "broker_kill_switch",
      label: "Broker kill switch",
      status: brokerKillActive ? "fail" : "pass",
      detail: brokerKillActive ? "At least one broker connection is disabled for this user." : "Broker-level kill switches are clear."
    },
    {
      code: "daily_loss_lockout",
      label: "Daily loss lockout",
      status: settings.dailyLossLockoutActive || Math.abs(Math.min(dailyPnlPct, 0)) >= settings.maxDailyLossPct ? "fail" : "pass",
      detail: settings.dailyLossLockoutActive
        ? "Daily loss lockout is active."
        : `Estimated daily loss is ${dailyPnlPct}% against a ${settings.maxDailyLossPct}% limit.`
    },
    {
      code: "max_open_positions",
      label: "Max open positions",
      status: openPositions + openOrders < settings.maxOpenPositions ? "pass" : "fail",
      detail: `${openPositions} open position(s) and ${openOrders} queued/sent order(s) against ${settings.maxOpenPositions} allowed.`
    },
    {
      code: "automation_enabled",
      label: "User automation",
      status: settings.automationEnabled ? "pass" : "warn",
      detail: settings.automationEnabled ? "Automation is enabled for this user." : "Automation is disabled for this user."
    }
  ];
}

export async function canUserExecuteLiveOrders(userId: string, symbol: string, riskPct: number, brokerConnectionId?: string | null) {
  const settings = await getUserRiskSettings(userId);
  const syntheticChecks = buildUserRiskChecks(settings, [], []);
  const symbolAllowed = settings.allowedSymbols.includes(symbol.toUpperCase());
  const riskAllowed = riskPct <= settings.maxRiskPerTradePct;
  const brokerAllowed = brokerConnectionId ? !settings.brokerKillSwitches[brokerConnectionId] : true;
  const blockers = [
    ...syntheticChecks.filter((check) => check.status === "fail").map((check) => `${check.label}: ${check.detail}`),
    ...(symbolAllowed ? [] : [`Symbol ${symbol} is not enabled for this user.`]),
    ...(riskAllowed ? [] : [`Risk ${riskPct}% exceeds user limit ${settings.maxRiskPerTradePct}%.`]),
    ...(brokerAllowed ? [] : ["Broker connection kill switch is active."])
  ];

  return {
    allowed: blockers.length === 0,
    settings,
    blockers
  };
}
