import { listSignedInAuditEvents } from "./audit-log";
import { getUserAccountState } from "./account-state";
import { listUserBrokerConnections } from "./user-auth";
import { getSignedInUserRisk } from "./user-risk";

function brokerSummary(connections: Awaited<ReturnType<typeof listUserBrokerConnections>>) {
  const connected = connections.filter((connection) => connection.status === "connected").length;
  const pending = connections.filter((connection) => connection.status === "pending").length;
  const failed = connections.filter((connection) => connection.status === "failed").length;

  return {
    total: connections.length,
    connected,
    pending,
    failed,
    hasConnectedBroker: connected > 0
  };
}

function riskSummary(risk: Awaited<ReturnType<typeof getSignedInUserRisk>>) {
  const failedChecks = risk.checks.filter((check) => check.status === "fail");
  const warningChecks = risk.checks.filter((check) => check.status === "warn");

  return {
    status: failedChecks.length ? "blocked" : warningChecks.length ? "attention" : "clear",
    failedCount: failedChecks.length,
    warningCount: warningChecks.length,
    canAutomate: risk.settings.automationEnabled && !risk.settings.userKillSwitchActive && failedChecks.length === 0
  };
}

export async function getMeOverview(request: Request) {
  const [accountState, brokerConnections, risk, activity] = await Promise.all([
    getUserAccountState(request),
    listUserBrokerConnections(request),
    getSignedInUserRisk(request),
    listSignedInAuditEvents(request, 10)
  ]);

  const latestSnapshot = accountState.latestSnapshot;
  const openPositions = accountState.positions.filter((position) => position.side !== "unknown");
  const recentOrders = accountState.executionOrders.slice(0, 10);
  const pendingOrders = accountState.executionOrders.filter((order) => order.status === "queued" || order.status === "sent");

  return {
    user: accountState.user,
    onboarding: {
      completed: Boolean(accountState.user.profile.onboardingCompletedAt),
      automationMode: accountState.user.profile.automationMode,
      needsBrokerConnection: brokerConnections.length === 0,
      needsRiskConsent: !risk.settings.automationEnabled
    },
    brokers: {
      summary: brokerSummary(brokerConnections),
      connections: brokerConnections
    },
    account: {
      latestSnapshot,
      equity: latestSnapshot?.equity ?? null,
      balance: latestSnapshot?.balance ?? null,
      currency: latestSnapshot?.currency ?? accountState.user.profile.baseCurrency,
      positionsOpen: openPositions.length,
      pendingOrders: pendingOrders.length
    },
    risk: {
      summary: riskSummary(risk),
      settings: risk.settings,
      checks: risk.checks
    },
    execution: {
      recentOrders,
      pendingOrders
    },
    activity
  };
}
